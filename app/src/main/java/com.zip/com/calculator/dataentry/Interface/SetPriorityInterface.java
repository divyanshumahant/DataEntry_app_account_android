package com.calculator.dataentry.Interface;

public interface SetPriorityInterface {

    public void setPriorityEvent(String tok,String a, String b , String c , String d, String e, int p, String type) ;

}
