package com.calculator.dataentry.Interface;

public interface EditInterface {

    public  void editEvent(String name, String title, String desc, long stime, long etime);
}
