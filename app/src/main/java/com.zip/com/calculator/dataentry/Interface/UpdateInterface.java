package com.calculator.dataentry.Interface;

public interface UpdateInterface {

    public  void updatedate();
}
