package com.calculator.dataentry.model;

import com.google.gson.annotations.SerializedName;

public class formDataModel {
    @SerializedName("status")
    public String status;



}
