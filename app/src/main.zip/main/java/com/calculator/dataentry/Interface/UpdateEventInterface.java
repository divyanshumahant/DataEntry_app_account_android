package com.calculator.dataentry.Interface;

public interface UpdateEventInterface {
    void UpdateEvent(String s);
}
