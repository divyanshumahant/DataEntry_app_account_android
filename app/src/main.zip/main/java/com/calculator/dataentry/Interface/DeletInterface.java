package com.calculator.dataentry.Interface;

public interface DeletInterface {

    public void DeletEvent(int position) ;
}
